import Home from './Home.jsx'
import AddPost from './AddPost.jsx'
import EditPost from './Editpost.jsx'
import MyPosts from './MyPosts.jsx'
import Login from './Login.jsx'
import Post from './Post.jsx'
import Signup from './Signup.jsx'

export {Home,
        AddPost,
        EditPost,
        MyPosts,
        Login,
        Post,
        Signup
}